# meshery

![Version: 0.6.0](https://img.shields.io/badge/Version-0.6.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square)

Meshery chart for deploying Meshery

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Meshery Authors | <maintainers@meshery.io> |  |

## Values

| Key                                             | Type | Default                                                                                                                                                                                               | Description |
|-------------------------------------------------|------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|
| affinity                                        | object | `{}`                                                                                                                                                                                                  |  |
| annotations                                     | object | `{}`                                                                                                                                                                                                  |  |
| env.ADAPTER_URLS                                | string | `"meshery-istio:10000 meshery-linkerd:10001 meshery-consul:10002 meshery-kuma:10007 meshery-nginx-sm:10010 meshery-nsm:10004 meshery-app-mesh:10005 meshery-traefik-mesh:10006 meshery-cilium:10012"` | Optionally, pre-configure Meshery Server with the set of Meshery Adapters used in the deployment. |
| env.EVENT                                       | string | `"mesheryLocal"`                                                                                                                                                                                      |  |
| env.PROVIDER                                    | string | `"Local"`                                                                                                                                                                                             | Use this security-related setting to enforce selection of one and only one Provider. In this way, your Meshery deployment will only trust and only allow users to authenticate using the Provider you have configured in this setting. See the [Remote Provider documentation](https://docs.meshery.io/extensibility/providers) for a description of what a Provider is.  |
| env.MESHERY_SERVER_CALLBACK_URL                 | string | `""`                                                                                                                                                                                                  | Configure an OAuth callback URL for Meshery Server to use when signing into a Remote Provider and your Meshery Server instance is not directly reachable by that Remote Provider. See the [Remote Provider documentation](https://docs.meshery.io/extensibility/providers#configurable-oauth-callback-url) for more details. |
| env.MESHSYNC_DEFAULT_DEPLOYMENT_MODE            | string | `"operator"` | Configure the deployment mode for Meshsync. Possible values are `embedded` (runs as a library inside Meshery Server process, one routine per connected Kubernetes cluster) and `operator` (deployed in managed k8s cluster, managed by Meshery Operator, one deployment per connected Kubernetes cluster). See the [Meshsync deployment documentation](https://docs.meshery.io/concepts/architecture/meshsync#meshsync-deployment-mode) for more details. |
| env.PROVIDER_BASE_URLS                          | string | `"https://cloud.meshery.io,https://cloud.layer5.io"`                                                                                                                                                  | Comma-separated list of Remote Provider URLs to register on this Meshery server. The first reachable provider is treated as the default. See the [Remote Provider documentation](https://docs.meshery.io/extensibility/providers) for a description of what a Provider is. |
| fullnameOverride                                | string | `""`                                                                                                                                                                                                  |  |
| image.pullPolicy                                | string | `"Always"`                                                                                                                                                                                            |  |
| image.repository                                | string | `"meshery/meshery"`                                                                                                                                                                                    |  |
| image.tag                                       | string | `"stable-latest"`                                                                                                                                                                                     |  |
| imagePullSecrets                                | list | `[]`                                                                                                                                                                                                  |  |
| ingress.annotations                             | object | `{}`                                                                                                                                                                                                  |  |
| ingress.enabled                                 | bool | `false`                                                                                                                                                                                               |  |
| ingress.hosts[0].host                           | string | `"chart-example.local"`                                                                                                                                                                               |  |
| ingress.hosts[0].paths                          | list | `[]`                                                                                                                                                                                                  |  |
| ingress.tls                                     | list | `[]`                                                                                                                                                                                                  |  |
| meshery-app-mesh.enabled                        | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-app-mesh.fullnameOverride               | string | `"meshery-app-mesh"`                                                                                                                                                                                  |  |
| meshery-app-mesh.serviceAccountNameOverride     | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-cilium.enabled                          | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-cilium.fullnameOverride                 | string | `"meshery-cilium"`                                                                                                                                                                                    |  |
| meshery-consul.enabled                          | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-consul.fullnameOverride                 | string | `"meshery-consul"`                                                                                                                                                                                    |  |
| meshery-consul.serviceAccountNameOverride       | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-istio.enabled                           | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-istio.fullnameOverride                  | string | `"meshery-istio"`                                                                                                                                                                                     |  |
| meshery-istio.serviceAccountNameOverride        | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-kuma.enabled                            | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-kuma.fullnameOverride                   | string | `"meshery-kuma"`                                                                                                                                                                                      |  |
| meshery-kuma.serviceAccountNameOverride         | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-linkerd.enabled                         | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-linkerd.fullnameOverride                | string | `"meshery-linkerd"`                                                                                                                                                                                   |  |
| meshery-linkerd.serviceAccountNameOverride      | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-nginx-sm.enabled                        | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-nginx-sm.fullnameOverride               | string | `"meshery-nginx-sm"`                                                                                                                                                                                  |  |
| meshery-nginx-sm.serviceAccountNameOverride     | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-nsm.enabled                             | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-nsm.fullnameOverride                    | string | `"meshery-nsm"`                                                                                                                                                                                       |  |
| meshery-nsm.serviceAccountNameOverride          | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-operator.enabled                        | bool | `true`                                                                                                                                                                                                | Enable to deploy this Meshery Operator upon initial deploymeent. Meshery Operator can be deployed post-installation using Meshery UI. |
| meshery-operator.fullnameOverride               | string | `"meshery-operator"`                                                                                                                                                                                  |  |
| meshery-osm.enabled                             | bool | `false`                                                                                                                                                                                               | OSM is an archived project. |
| meshery-osm.fullnameOverride                    | string | `"meshery-osm"`                                                                                                                                                                                       |  |
| meshery-osm.serviceAccountNameOverride          | string | `"meshery-server"`                                                                                                                                                                                    |  |
| meshery-traefik-mesh.enabled                    | bool | `false`                                                                                                                                                                                               | Enable to deploy this Meshery Adapter upon initial deployment. Meshery Adapters can be deployed post-installation using either Meshery CLI or UI. |
| meshery-traefik-mesh.fullnameOverride           | string | `"meshery-traefik-mesh"`                                                                                                                                                                              |  |
| meshery-traefik-mesh.serviceAccountNameOverride | string | `"meshery-server"`                                                                                                                                                                                    |  |
| mesherygateway.enabled                          | bool | `false`                                                                                                                                                                                               |  |
| mesherygateway.selector.istio                   | string | `"ingressgateway"`                                                                                                                                                                                    |  |
| metadata.name                                   | string | `"meshery"`                                                                                                                                                                                           |  |
| metadata.namespace                              | string | `"meshery"`                                                                                                                                                                                           |  |
| nameOverride                                    | string | `""`                                                                                                                                                                                                  |  |
| nodeSelector                                    | object | `{}`                                                                                                                                                                                                  |  |
| podSecurityContext                              | object | `{}`                                                                                                                                                                                                  |  |
| probe.livenessProbe.enabled                     | bool | `false`                                                                                                                                                                                               |  |
| probe.readinessProbe.enabled                    | bool | `false`                                                                                                                                                                                               |  |
| rbac.nodes                                      | bool | `false`                                                                                                                                                                                               |  |
| replicaCount                                    | int | `1`                                                                                                                                                                                                   |  |
| resources                                       | object | `{}`                                                                                                                                                                                                  |  |
| restartPolicy                                   | string | `"Always"`                                                                                                                                                                                            |  |
| securityContext                                 | object | `{}`                                                                                                                                                                                                  |  |
| service.annotations                             | object | `{}`                                                                                                                                                                                                  |  |
| service.port                                    | int | `9081`                                                                                                                                                                                                |  |
| service.target_port                             | int | `8080`                                                                                                                                                                                                |  |
| service.type                                    | string | `"LoadBalancer"`                                                                                                                                                                                      |  |
| serviceAccount.name                             | string | `"meshery-server"`                                                                                                                                                                                    |  |
| testCase.enabled                                | bool | `false`                                                                                                                                                                                               |  |
| tolerations                                     | list | `[]`                                                                                                                                                                                                  |  |

## Setup Repo Info

```console
helm repo add meshery https://meshery.io/charts/
helm repo update

```

_See [helm repo](https://helm.sh/docs/helm/helm_repo/) for command documentation._

## Installing the Chart

To install the chart with the release name `meshery`:

```console
helm install meshery meshery/meshery --namespace meshery --create-namespace

```

## Upgrading the Chart

To upgrade an existing `meshery` deployment:

```console
# Upgrade with recommended settings for upgrades
helm upgrade meshery meshery/meshery --namespace meshery -f values-upgrade.yaml --wait --timeout 10m

# Or upgrade with default settings
helm upgrade meshery meshery/meshery --namespace meshery
```

See [HEALTHCHECKS.md](HEALTHCHECKS.md) for detailed information about health check configuration during upgrades.

## Uninstalling the Chart

To uninstall `meshery` helm release:

```console
helm uninstall meshery --namespace meshery

```

## Installing the Chart with one or more Meshery Adapters

Eg: For [Meshery Adapter for Istio](https://github.com/meshery/meshery-istio)
```console
helm install meshery meshery/meshery --set meshery-istio.enabled=true --namespace meshery --create-namespace
```

## Health Checks and Probes

Meshery implements Kubernetes-compliant health check endpoints for liveness and readiness probes:

- **Liveness Probe**: `/healthz/live` - Checks if Meshery server is alive and responsive
- **Readiness Probe**: `/healthz/ready` - Checks if Meshery is ready to accept traffic (includes capability validation)

### Default Probe Configuration

The chart includes pre-configured health checks with sensible defaults:

```yaml
probe:
  livenessProbe:
    enabled: true
    initialDelaySeconds: 80
    periodSeconds: 12
    failureThreshold: 4

  readinessProbe:
    enabled: true
    initialDelaySeconds: 10
    periodSeconds: 4
    failureThreshold: 4
```

### Monitoring Health Status

Check detailed health status with verbose output:

```console
kubectl exec --namespace meshery deployment/meshery -- curl -s "http://localhost:8080/healthz/ready?verbose=1"
```

Example output:
```
[+]capabilities ok
[i]extension extension package found
healthz check passed
```

### Customizing Probes

For specific deployment scenarios, you can customize probe settings in your `values.yaml`:

```yaml
probe:
  # Enable startup probe for slow-starting containers (Kubernetes 1.18+)
  startupProbe:
    enabled: true
    periodSeconds: 10
    failureThreshold: 30  # Allow up to 5 minutes for startup

  livenessProbe:
    enabled: true
    initialDelaySeconds: 120  # Adjust based on your environment
    periodSeconds: 15
    failureThreshold: 5

  readinessProbe:
    enabled: true
    initialDelaySeconds: 20
    periodSeconds: 5
    failureThreshold: 4
```

### Documentation

For comprehensive guidance on health check configuration, including:
- Installation vs upgrade considerations
- Troubleshooting common issues
- Advanced configuration options
- Best practices

See the detailed [HEALTHCHECKS.md](HEALTHCHECKS.md) documentation.

## Additional Resources

- [Meshery Documentation](https://docs.meshery.io/)
- [Kubernetes Probes Documentation](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/)
- [GitHub Repository](https://github.com/meshery/meshery)
